﻿using System.Collections.Generic;

namespace JmakerServer
{
  internal class Keyboard {
    private Dictionary<char, KeyCode> numKeys = new Dictionary<char, KeyCode>() {
      {'0', KeyCode.VK_NUMPAD0},
      {'1', KeyCode.VK_NUMPAD1},
      {'2', KeyCode.VK_NUMPAD2},
      {'3', KeyCode.VK_NUMPAD3},
      {'4', KeyCode.VK_NUMPAD4},
      {'5', KeyCode.VK_NUMPAD5},
      {'6', KeyCode.VK_NUMPAD6},
      {'7', KeyCode.VK_NUMPAD7},
      {'8', KeyCode.VK_NUMPAD8},
      {'9', KeyCode.VK_NUMPAD9},
      {'+', KeyCode.VK_ADD}, 
      {'R', KeyCode.VK_R},
      {'U', KeyCode.VK_U},
      {'S', KeyCode.VK_S},
      {'K', KeyCode.VK_K},
      {'Z', KeyCode.VK_Z},
      {'A', KeyCode.VK_A}
    };

    public void KeyStrokes(string number) {
      for (int index = 0; index < number.Length; ++index) {
        char key = number[index];
        if (this.numKeys.ContainsKey(key))
          WinAPI.PressKey(this.numKeys[key]);
      }
    }

    public void Delete() {
      WinAPI.keybd_event((byte) 17, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 65, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 17, (byte) 0, 2U, 0);
      WinAPI.keybd_event((byte) 65, (byte) 0, 2U, 0);
      WinAPI.PressKey(KeyCode.VK_DELETE);
    }

    public void InsertText() {
      WinAPI.keybd_event((byte) 17, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 86, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 17, (byte) 0, 2U, 0);
      WinAPI.keybd_event((byte) 86, (byte) 0, 2U, 0);
    }

    public void CopyText() {
      WinAPI.keybd_event((byte) 17, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 65, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 17, (byte) 0, 2U, 0);
      WinAPI.keybd_event((byte) 65, (byte) 0, 2U, 0);
      WinAPI.keybd_event((byte) 17, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 67, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 17, (byte) 0, 2U, 0);
      WinAPI.keybd_event((byte) 67, (byte) 0, 2U, 0);
    }

    public void OpenFileDialog() {
      WinAPI.keybd_event((byte) 17, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 80, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 17, (byte) 0, 2U, 0);
      WinAPI.keybd_event((byte) 80, (byte) 0, 2U, 0);
    }

    public void OpenDialer() {
      WinAPI.keybd_event((byte) 17, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 68, (byte) 0, 0U, 0);
      WinAPI.keybd_event((byte) 17, (byte) 0, 2U, 0);
      WinAPI.keybd_event((byte) 68, (byte) 0, 2U, 0);
    }

    public void Enter() {
      WinAPI.PressKey(KeyCode.VK_RETURN);
    }
  }
}
