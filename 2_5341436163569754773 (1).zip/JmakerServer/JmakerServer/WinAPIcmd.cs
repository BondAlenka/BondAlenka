﻿// Decompiled with JetBrains decompiler
// Type: Jmaker.WinAPIcmd
// Assembly: Jmaker, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F7663B89-0B2D-4474-A161-E78A8B1A5775
// Assembly location: D:\Dev\Messengers\ViberClicker\JmakerStart.exe

namespace JmakerServer
{
    public enum WinAPIcmd : uint {
        MOUSEEVENTF_MOVE = 1U,
        KEYEVENTF_KEYUP = 2U,
        MOUSEEVENTF_LEFTDOWN = 2U,
        MOUSEEVENTF_LEFTUP = 4U,
        SW_SHOW = 5U,
        SW_RESTORE = 9U,
        SW_MINIMIZE = 6U,
        WM_SETTEXT = 12U,
        WM_GETTEXT = 13U,
        WM_CLOSE = 16U,
        WM_KEYDOWN = 256U,
        WM_KEYUP = 257U,
        CB_SETCURSEL = 334U,
        CB_SETDROPPEDWIDTH = 352U,
        WM_LBUTTONDOWN = 513U,
        WM_LBUTTONUP = 514U,
    }
}
