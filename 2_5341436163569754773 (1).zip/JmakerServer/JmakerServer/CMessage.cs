﻿namespace JmakerServer
{
    public class CMessage
    {
        public int mid { get; set; }
        public string Phone { get; set; }
        public string FullPhone { get; set; }
        public string Country { get; set; }
        public string Text { get; set; }
        public bool IsSent { get; set; }
        public bool IsError { get; set; }
        public string Status { get; set; }

        public CMessage(){}
        public CMessage(string Country, string FullPhone, string Phone, string Text, int mid, bool IsSent, bool IsError, string Status)
        {
            this.Country = Country;
            this.Phone = Phone;
            this.FullPhone = FullPhone;
            this.Text = Text;
            this.mid = mid;
            this.IsSent = IsSent;
            this.IsError = IsError;
            this.Status = Status;
        }
    }
}
