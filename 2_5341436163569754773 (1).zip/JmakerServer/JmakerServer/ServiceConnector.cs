﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace JmakerServer
{
    public class ServiceConnector
    {
        public string Url { get; set; }

        public ServiceConnector()
        {
            /* Url = "ht tp://172.26.2.220/service/jmaker/"; */
            Url = "http://127.0.0.1/script/jmaker/";
        }

        public bool RequestMessages(int count, string country = "", string account = "")
        {
            var mem = new MemoryStream();
            var xws = new XmlWriterSettings {Indent = false, Encoding = new UTF8Encoding(false)};
            var xml = "";

            var writer = XmlWriter.Create(mem, xws);
            writer.WriteStartDocument();
            writer.WriteStartElement("data");
            writer.WriteStartElement("get");
            writer.WriteAttributeString("count", count.ToString());
            if (country != "") writer.WriteAttributeString("country", country);
            if (account != "") writer.WriteAttributeString("account", account);
            writer.Close();
            xml = Encoding.UTF8.GetString(mem.ToArray());

            string response = postXMLData(xml);

            Program.queue.Reset();
            var reader = XmlReader.Create(new StringReader(response));
            var success = false;
            while(reader.Read())
            {
                if(reader.NodeType == XmlNodeType.Element && reader.Name == "message")
                {
                    success = true;

                    var Country = reader.GetAttribute("country") ?? "";
                    var MID = Convert.ToInt32(reader.GetAttribute("mid") ?? "0");
                    var FullPhone = reader.GetAttribute("phone") ?? "";
                    var Phone = FullPhone;
                    var Text = reader.GetAttribute("text") ?? "";
                    var Status = "new";
                    var IsError = false;
                    var IsSent = false;

                    if(Country=="" && FullPhone.Substring(0, 1)=="+")
                    {
                        if(FullPhone.Substring(0, 4) == "+380")
                        {
                            Phone = FullPhone.Substring(4);
                            Country = "UKR";
                        }
                        if(FullPhone.Substring(0, 3) == "+77" || FullPhone.Substring(0, 3) == "+76")
                        {
                            Phone = FullPhone.Substring(2);
                            Country = "KAZ";
                        }
                        else if(FullPhone.Substring(0, 2) == "+7")
                        {
                            Phone = FullPhone.Substring(2);
                            Country = "RUS";
                        }
                    }

                    Program.queue.AddMessageToSend(
                        new CMessage(Country, FullPhone, Phone, Text, MID, IsSent, IsError, Status)
                    );
                }
            }

            return success;
        }

        public bool SendResults()
        {
            var mem = new MemoryStream();
            var xws = new XmlWriterSettings() {Indent = false, Encoding = new UTF8Encoding(false)};
            var xml = "";
            
            var writer = XmlWriter.Create(mem, xws);

            writer.WriteStartElement("data");

            // -- sent ok list
            foreach(var msg in Program.queue.GetSentList())
            {
                writer.WriteStartElement("result");
                writer.WriteAttributeString("mid", msg.mid.ToString());
                writer.WriteAttributeString("phone", msg.Phone);
                writer.WriteAttributeString("sent", msg.IsSent ? "Y" : "N");
                writer.WriteAttributeString("status", msg.Status);
                writer.WriteEndElement();
            }

            // -- failed list
            foreach (var msg in Program.queue.GetFailedList())
            {
                writer.WriteStartElement("result");
                writer.WriteAttributeString("mid", msg.mid.ToString());
                writer.WriteAttributeString("phone", msg.Phone);
                writer.WriteAttributeString("sent", msg.IsSent ? "Y" : "N");
                writer.WriteAttributeString("status", msg.Status);
                writer.WriteEndElement();
            }

            writer.Close();
            xml = Encoding.UTF8.GetString(mem.ToArray());

            var response = postXMLData(xml);

            var reader = XmlReader.Create(new StringReader(response));
            var result = false;
            while(reader.Read())
            {
                if(reader.NodeType == XmlNodeType.Element && reader.Name == "data")
                {
                    if(reader.GetAttribute("result") == "ok")
                    {
                        result = true;
                    }
                }
            }
            return result;
        }

        public void SendLogMessage(string message, string type = "INFO")
        {
            var output = new StringBuilder();
            var xws = new XmlWriterSettings();
            xws.Indent = false;
            var writer = XmlWriter.Create(output, xws);
            writer.WriteStartElement("log");
            writer.WriteAttributeString("type", type);
            writer.WriteAttributeString("message", message);
            writer.WriteEndElement();
            writer.Close();

            postXMLData(output.ToString());
        }

        private string postXMLData(string requestXml)
        {
            string destinationUrl = Url;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(destinationUrl);
            byte[] bytes;
            bytes = Encoding.ASCII.GetBytes(requestXml);
            request.ContentType = "text/xml; encoding='utf-8'";
            request.ContentLength = bytes.Length;
            request.Method = "POST";
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(bytes, 0, bytes.Length);
            requestStream.Close();
            HttpWebResponse response;
            response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream responseStream = response.GetResponseStream();
                string responseStr = new StreamReader(responseStream).ReadToEnd();
                return responseStr;
            }
            return null;
        }
    }
}
