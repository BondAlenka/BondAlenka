﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading;
using System.Windows.Forms;

namespace JmakerServer
{
    class JmakerBot
    {
        private Mouse mouse = new Mouse();
        private Keyboard keyboard = new Keyboard();
        private PositionsManager manager;
        private IntPtr viberWindow;
        private string prevPhone = "";
        private string _lastFailReason = "";
        private string _lastFailReasonCode = "";
        private static int _delayActions = 300;
        Bitmap screenPixel = new Bitmap(1, 1, PixelFormat.Format32bppArgb);

        public string LastFailReason { get { return _lastFailReason; } }
        public string LastFailReasonCode { get { return _lastFailReasonCode; } }

        public IntPtr ViberWindow
        {
            get { return viberWindow; }
        }

        public static int DelayActions
        {
            get { return _delayActions; }
            set { _delayActions = value; }
        }

        public bool IsViberActive() { return WinAPI.GetWindowText(WinAPI.GetForegroundWindow()).IndexOf("Viber") != -1; }

        public JmakerBot() { FindViber(); }

        public bool FindViber()
        {
            viberWindow = WinAPI.GetHwnd("Viber");
            if (ViberWindow != IntPtr.Zero)
            {
                manager = new PositionsManager(ViberWindow);
                return true;
            }
            return false;
        }


        public bool SendMessage(string phone, string message, string country)
        {
            // -- activate Viber window
            WinAPI.RestoreWindow(ViberWindow);
            WinAPI.SetForegroundWindow(ViberWindow);
            WinAPI.SetActiveWindow(ViberWindow);
            Thread.Sleep(_delayActions);

            if (phone != prevPhone)
            {
                // -- open dialer tab (Ctrl+D)
                if (IsViberActive())
                {
                    KeyDown((byte)KeyCode.VK_CONTROL);
                    KeyDown((byte)KeyCode.VK_D);
                    KeyUp((byte)KeyCode.VK_D);
                    KeyUp((byte)KeyCode.VK_CONTROL);
                    Thread.Sleep(_delayActions);
                }
                else
                {
                    _lastFailReason = "Пользователь перешёл из окна Viber в другое окно. Процесс приостановлен.";
                    _lastFailReasonCode = "INTERRUPTED_BY_USER";
                    return false;
                }

                // -- remove prev phone number (Ctrl+A, Delete)
                if (IsViberActive())
                {
                    KeyDown((byte)KeyCode.VK_CONTROL);
                    KeyPress((byte)KeyCode.VK_A);
                    KeyUp((byte)KeyCode.VK_CONTROL);
                    Thread.Sleep(100);
                    KeyPress((byte)KeyCode.VK_DELETE);
                    Thread.Sleep(100);
                }
                else
                {
                    _lastFailReason = "Пользователь перешёл из окна Viber в другое окно. Процесс приостановлен.";
                    _lastFailReasonCode = "INTERRUPTED_BY_USER";
                    return false;
                }

                // -- open countries list (click)
                // -- select country, press ENTER
                if (IsViberActive())
                {
                    mouse.MouseClick(manager.GetPointByName("country"));
                    keyboard.KeyStrokes(country);
                    Thread.Sleep(100);
                    keyboard.Enter();
                    Thread.Sleep(_delayActions);
                }
                else
                {
                    _lastFailReason = "Пользователь перешёл из окна Viber в другое окно. Процесс приостановлен.";
                    _lastFailReasonCode = "INTERRUPTED_BY_USER";
                    return false;
                }

                // -- click on phone number input (click)
                // -- enter phone number (keyboard), press ENTER
                if (IsViberActive())
                {
                    mouse.MouseClick(manager.GetPointByName("phone"));
                    keyboard.KeyStrokes(phone);
                    Thread.Sleep(_delayActions);
                }
                else
                {
                    _lastFailReason = "Пользователь перешёл из окна Viber в другое окно. Процесс приостановлен.";
                    _lastFailReasonCode = "INTERRUPTED_BY_USER";
                    return false;
                }

                // -- click conversation button (click)
                if (IsViberActive())
                {
                    mouse.MouseClick(manager.GetPointByName("conversation"));
                    Thread.Sleep(_delayActions);
                }
                else
                {
                    _lastFailReason = "Пользователь перешёл из окна Viber в другое окно. Процесс приостановлен.";
                    _lastFailReasonCode = "INTERRUPTED_BY_USER";
                    return false;
                }
            }
            prevPhone = phone;

            // -- check if message field available
            if (IsViberActive())
            {
                Thread.Sleep(_delayActions);

                Color c = GetColorAt(manager.GetPointByName("message"));
                if (c.R > 240 && c.G > 240 && c.B > 240)
                {
                    mouse.MouseClick(manager.GetPointByName("message"));

                    // -- remove prev phone number (Ctrl+A, Delete)
                    if (IsViberActive())
                    {
                        KeyDown((byte)KeyCode.VK_CONTROL);
                        KeyPress((byte)KeyCode.VK_A);
                        KeyUp((byte)KeyCode.VK_CONTROL);
                        Thread.Sleep(100);
                        KeyPress((byte)KeyCode.VK_DELETE);
                        Thread.Sleep(100);
                    }
                    else
                    {
                        _lastFailReason = "Пользователь перешёл из окна Viber в другое окно. Процесс приостановлен.";
                        _lastFailReasonCode = "INTERRUPTED_BY_USER";
                        return false;
                    }

                    // -- insert and send message (Ctrl+V, ENTER)
                    if (IsViberActive())
                    {
                        Clipboard.SetText(message);
                        keyboard.InsertText();
                        Thread.Sleep(_delayActions);
                        keyboard.Enter();
                    }
                }
                else
                {
                    _lastFailReason = "У абонента нет Viber.";
                    _lastFailReasonCode = "NOT_VIBER_USER";
                    return false;
                }
            }
            else
            {
                _lastFailReason = "Пользователь перешёл из окна Viber в другое окно. Процесс приостановлен.";
                _lastFailReasonCode = "INTERRUPTED_BY_USER";
                return false;
            }

            _lastFailReasonCode = "";
            _lastFailReason = "";
            Cursor.Clip = new System.Drawing.Rectangle(0, 0, 0, 0);
            return true;
        }


        private void KeyDown(byte KeyCode)
        {
            WinAPI.keybd_event(KeyCode, 0, 0U, 0);
        }

        private void KeyUp(byte KeyCode)
        {
            WinAPI.keybd_event(KeyCode, 0, 2U, 0);
        }

        private void KeyPress(byte KeyCode)
        {
            KeyDown(KeyCode);
            Thread.Sleep(100);
            KeyUp(KeyCode);
            Thread.Sleep(100);
        }

        public Color GetColorAt(Point location)
        {
            using (Graphics gdest = Graphics.FromImage(screenPixel))
            {
                using (Graphics gsrc = Graphics.FromHwnd(IntPtr.Zero))
                {
                    IntPtr hSrcDC = gsrc.GetHdc();
                    IntPtr hDC = gdest.GetHdc();
                    WinAPI.BitBlt(hDC, 0, 0, 1, 1, hSrcDC, location.X, location.Y, (int)CopyPixelOperation.SourceCopy);
                    gdest.ReleaseHdc();
                    gsrc.ReleaseHdc();
                }
            }

            return screenPixel.GetPixel(0, 0);
        }



    }
}
