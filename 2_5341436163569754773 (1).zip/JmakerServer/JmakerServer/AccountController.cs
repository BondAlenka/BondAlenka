﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace JmakerServer
{
    public class AccountController
    {
        private string currentPhone;
        private string currentAccountDbFile;

        private const string accountsArchive = "C:\\ViberAccounts";
        private string ViberPCFolder;
        public static string ViberAppPath;

        public string CurrentPhone { get { return currentPhone; } }
        public string CurrentAccountDbFile { get { return currentAccountDbFile; } }
        public string AccountsFolder { get; set; }

        //private SQLiteConnection _sqliteViber;
        //private SQLiteCommand _cmdCheckViber;
        //private SQLiteConnection _sqliteJmaker;

        public AccountController()
        {
        
        }

        /** get list of accounts in archive **/
        public List<string> GetAvailableAccounts()
        {
            List<string> newList = new List<string>();
            foreach (var folder in Directory.EnumerateDirectories(accountsArchive, "ViberPC_*"))
            {
                var cAccPhone = folder.Substring(folder.LastIndexOf("_") + 1);
                if (cAccPhone != "") // -- don't mention "ViberPC_" folder
                {
                    newList.Add(cAccPhone);
                }
            }
            return newList;
        }

        /** get account currently activated **/
        public bool GetCurrentAccountDatabase()
        {
            string accPath;

            // -- get AppData\Roaming\ViberPC folder
            ViberPCFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ViberPC");

            if (Directory.Exists(ViberPCFolder))
            {
                // -- enum folders
                var folders = new List<string>(Directory.EnumerateDirectories(ViberPCFolder));

                // -- remove "data" folder from list
                int i = folders.FindIndex(findStr => findStr.IndexOf("data") != -1);
                if (i != -1)
                    folders.RemoveAt(i);

                // -- if any elements left in array
                if (folders.Count > 0)
                {
                    // -- select first of them
                    accPath = folders.ElementAt(0);
                    currentPhone = accPath.Substring(accPath.LastIndexOf("\\") + 1);
                    currentAccountDbFile = Path.Combine(accPath, "viber.db");
                    return true;
                }
            }
            return false;
        }


        /** =====================================================
         *   Close current Viber account and move it to archive
         ** ===================================================== */
        public bool CloseCurrentAccount()
        {
            if (Directory.EnumerateDirectories(ViberPCFolder).Count() > 0 && currentPhone != "")
            {
                var arcAccFolder = Path.Combine(accountsArchive, "ViberPC_" + currentPhone);

                // -- create ViberPC_<account> folder
                if (!Directory.Exists(arcAccFolder))
                    Directory.CreateDirectory(arcAccFolder);

                // -- move DATA folder
                if (Directory.Exists(Path.Combine(accountsArchive, "data")))
                    Directory.Delete(Path.Combine(accountsArchive, "data"), true);

                if (Directory.Exists(Path.Combine(ViberPCFolder, "data")))
                    Directory.Move(Path.Combine(ViberPCFolder, "data"), Path.Combine(accountsArchive, "data"));
                else
                    Logger.Write("Unable to move 'data' folder to '" + accountsArchive + "': does not exists");

                // -- move account folder
                if (Directory.Exists(Path.Combine(ViberPCFolder, currentPhone)))
                    Directory.Move(Path.Combine(ViberPCFolder, currentPhone), Path.Combine(arcAccFolder, currentPhone));
                else
                    Logger.Write("Unable to move '" + Path.Combine(ViberPCFolder, currentPhone) + "' folder to '" + accountsArchive + "': does not exists");

                // -- move config.db & info.db files)););
                if (File.Exists(Path.Combine(ViberPCFolder, "config.db")))
                    File.Move(Path.Combine(ViberPCFolder, "config.db"), Path.Combine(arcAccFolder, "config.db"));
                else
                    Logger.Write("Unable to move 'config.db' file to '" + arcAccFolder + "': does not exists");

                if (File.Exists(Path.Combine(ViberPCFolder, "info.db")))
                    File.Move(Path.Combine(ViberPCFolder, "info.db"), Path.Combine(arcAccFolder, "info.db"));
                else
                    Logger.Write("Unable to move 'info.db' file to '" + arcAccFolder + "': does not exists");

            }
            currentPhone = "";
            currentAccountDbFile = "";

            return true;
        }

        public bool CloseViber()
        {
            try
            {
                Process[] proc = Process.GetProcessesByName("Viber");
                if (proc.Count() == 1)
                {
                    proc[0].Kill();
                    while (WinAPI.GetHwnd("Viber") != IntPtr.Zero)
                    {
                        Application.DoEvents();
                        Thread.Sleep(200);
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }


    }
}
