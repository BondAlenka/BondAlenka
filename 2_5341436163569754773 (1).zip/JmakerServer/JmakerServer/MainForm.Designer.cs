﻿namespace JmakerServer
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSetSettings = new System.Windows.Forms.Button();
            this.txtInstanceName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtServiceUrl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tmProcess = new System.Windows.Forms.Timer(this.components);
            this.btnRun1 = new System.Windows.Forms.Button();
            this.btnRun2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSetSettings);
            this.groupBox1.Controls.Add(this.txtInstanceName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtServiceUrl);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(413, 147);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Settings";
            // 
            // btnSetSettings
            // 
            this.btnSetSettings.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnSetSettings.Location = new System.Drawing.Point(3, 115);
            this.btnSetSettings.Name = "btnSetSettings";
            this.btnSetSettings.Size = new System.Drawing.Size(407, 29);
            this.btnSetSettings.TabIndex = 4;
            this.btnSetSettings.Text = "Save settings";
            this.btnSetSettings.UseVisualStyleBackColor = true;
            this.btnSetSettings.Click += new System.EventHandler(this.btnSetSettings_Click);
            // 
            // txtInstanceName
            // 
            this.txtInstanceName.Location = new System.Drawing.Point(110, 43);
            this.txtInstanceName.Name = "txtInstanceName";
            this.txtInstanceName.Size = new System.Drawing.Size(297, 20);
            this.txtInstanceName.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Instance name";
            // 
            // txtServiceUrl
            // 
            this.txtServiceUrl.Location = new System.Drawing.Point(110, 19);
            this.txtServiceUrl.Name = "txtServiceUrl";
            this.txtServiceUrl.Size = new System.Drawing.Size(297, 20);
            this.txtServiceUrl.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Service URL";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(447, 24);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tmProcess
            // 
            this.tmProcess.Interval = 1000;
            this.tmProcess.Tick += new System.EventHandler(this.tmProcess_Tick);
            // 
            // btnRun1
            // 
            this.btnRun1.Location = new System.Drawing.Point(195, 232);
            this.btnRun1.Name = "btnRun1";
            this.btnRun1.Size = new System.Drawing.Size(78, 34);
            this.btnRun1.TabIndex = 2;
            this.btnRun1.Text = "test 1";
            this.btnRun1.UseVisualStyleBackColor = true;
            this.btnRun1.Click += new System.EventHandler(this.btnRun1_Click);
            // 
            // btnRun2
            // 
            this.btnRun2.Location = new System.Drawing.Point(279, 232);
            this.btnRun2.Name = "btnRun2";
            this.btnRun2.Size = new System.Drawing.Size(74, 34);
            this.btnRun2.TabIndex = 3;
            this.btnRun2.Text = "test 2";
            this.btnRun2.UseVisualStyleBackColor = true;
            this.btnRun2.Click += new System.EventHandler(this.btnRun2_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 331);
            this.Controls.Add(this.btnRun2);
            this.Controls.Add(this.btnRun1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Name = "MainForm";
            this.Text = "JmakerServer 1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtServiceUrl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtInstanceName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSetSettings;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer tmProcess;
        private System.Windows.Forms.Button btnRun1;
        private System.Windows.Forms.Button btnRun2;
    }
}

