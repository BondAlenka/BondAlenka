﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JmakerServer
{
    public class Queue
    {
        private readonly List<CMessage> listToSend = new List<CMessage>();
        private readonly List<CMessage> sentList = new List<CMessage>();
        private readonly List<CMessage> failedList = new List<CMessage>();

        public void Reset()
        {
            listToSend.Clear();
            sentList.Clear();
            failedList.Clear();
        }

        public List<CMessage> GetSentList()
        {
            return sentList;
        }
        public List<CMessage> GetFailedList()
        {
            return failedList;
        }

        public void AddMessageToSend(CMessage message)
        {
            listToSend.Add(message);
        }

        public int GetMessagesCount()
        {
            return listToSend.Count;
        }

        public bool TimeToSaveResults()
        {
            return listToSend.Count == 0 && (sentList.Count > 0 || failedList.Count > 0);
        }

        public CMessage GetMessage()
        {
            return listToSend.Count > 0 ? listToSend.ElementAt(0) : null;
        }

        public bool NextMessage(bool currentMessageSentOK = true, string sendStatus = "")
        {
            if(listToSend.Count > 0)
            {
                if(currentMessageSentOK)
                {
                    listToSend.ElementAt(0).IsSent = true;
                    listToSend.ElementAt(0).Status = sendStatus;
                    sentList.Add(listToSend.ElementAt(0));
                }
                else
                {
                    listToSend.ElementAt(0).IsError = true;
                    listToSend.ElementAt(0).Status = sendStatus;
                    failedList.Add(listToSend.ElementAt(0));
                }

                listToSend.RemoveAt(0);
                return true;
            }
            return false;
        }
    }
}
