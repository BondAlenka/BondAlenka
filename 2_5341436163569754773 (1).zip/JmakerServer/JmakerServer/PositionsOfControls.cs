﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace JmakerServer
{
    internal class PositionsOfControls {
        private Dictionary<string, Point> positions = new Dictionary<string, Point>() {
            {"phone",           new Point(200, 175)},
            {"dialer",          new Point(248, 90)},
            {"conversation",    new Point(186, 530)},
            {"send",            new Point(850, 650)}, 
            {"country",         new Point(86, 172)}
        };

        public Point this[string name] {
            get {
                return name != "message" ? positions[name] : getMessagePos();
            }
        }

        public Point getMessagePos()
        {
            IntPtr viberWindow = WinAPI.GetHwnd("Viber");
            if(viberWindow!=IntPtr.Zero)
            {
                Rectangle rect = WinAPI.GetWindowPosition(viberWindow);
                return new Point(rect.Width / 2+50, rect.Height - 30);
            }
            return new Point(0, 0);
        }
    }
}
