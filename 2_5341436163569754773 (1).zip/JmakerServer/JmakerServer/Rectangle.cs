﻿using System;
using System.Drawing;
using System.Globalization;

namespace JmakerServer
{
    public struct Rectangle {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;

        public int X {
            get {
                return this.Left;
            }
            set {
                Right -= this.Left - value;
                Left = value;
            }
        }

        public int Y {
            get {
                return this.Top;
            }
            set {
                Bottom -= this.Top - value;
                Top = value;
            }
        }

        public int Height {
            get {
                return Bottom - Top;
            }
            set {
                Bottom = value + Top;
            }
        }

        public int Width {
            get {
                return Right - Left;
            }
            set {
                Right = value + Left;
            }
        }

        public Point Location {
            get {
                return new Point(Left, Top);
            }
            set {
                X = value.X;
                Y = value.Y;
            }
        }

        public Size Size {
            get {
                return new Size(Width, Height);
            }
            set {
                Width = value.Width;
                Height = value.Height;
            }
        }

        public Rectangle(int left, int top, int right, int bottom) {
            Left = left;
            Top = top;
            Right = right;
            Bottom = bottom;
        }

        public Rectangle(System.Drawing.Rectangle r) {
            this = new Rectangle(r.Left, r.Top, r.Right, r.Bottom);
        }

        public static implicit operator System.Drawing.Rectangle(Rectangle r) {
            return new System.Drawing.Rectangle(r.Left, r.Top, r.Width, r.Height);
        }

        public static implicit operator Rectangle(System.Drawing.Rectangle r) {
            return new Rectangle(r);
        }

        public static bool operator ==(Rectangle r1, Rectangle r2) {
            return r1.Equals(r2);
        }

        public static bool operator !=(Rectangle r1, Rectangle r2) {
            return !r1.Equals(r2);
        }

        public bool Equals(Rectangle r) {
            return r.Left == this.Left && r.Top == this.Top && r.Right == this.Right && r.Bottom == this.Bottom;
        }

        public override bool Equals(object obj) {
            if (obj is Rectangle)
                return this.Equals((Rectangle) obj);
            if (obj is System.Drawing.Rectangle)
                return this.Equals(new Rectangle((System.Drawing.Rectangle) obj));
            return false;
        }

        public override int GetHashCode() {
            //return (System.Drawing.Rectangle) this.GetHashCode();
            return 0;
        }

        public override string ToString() {
            return string.Format((IFormatProvider) CultureInfo.CurrentCulture, "{{Left={0},Top={1},Right={2},Bottom={3}}}", (object) this.Left, (object) this.Top, (object) this.Right, (object) this.Bottom);
        }
    }
}
