﻿// Decompiled with JetBrains decompiler
// Type: Jmaker.Mouse
// Assembly: Jmaker, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F7663B89-0B2D-4474-A161-E78A8B1A5775
// Assembly location: D:\Dev\Messengers\ViberClicker\JmakerStart.exe

using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace JmakerServer
{
    internal class Mouse {
        private void SetCursorPos(Point p) {
            WinAPI.SetCursorPos(p.X, p.Y);
        }

        public void MouseClick(Point p) {
            SetCursorPos(p);
            Cursor.Clip = new System.Drawing.Rectangle(p, new Size(1,1));
            Thread.Sleep(100);
            WinAPI.MouseClick(p.X, p.Y);
        }
    }
}
