﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace JmakerServer
{
    public class QueueProcessor
    {
        private JmakerBot bot;
        public static bool enabled;
        public static int defaultCount = 10;
        private CMessage message;
        private bool f1 = true;

        public QueueProcessor()
        {

        }

        public void ProcessBatch()
        {
            new Thread(Processor).Start();
        }

        public void Processor()
        {
            Program.sc.RequestMessages(defaultCount, "RUS", Program.ac.CurrentPhone);

            while ((message = Program.queue.GetMessage()) != null)
            {
                if (MessageBox.Show(message.Text, "Message sent OK ?", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Program.queue.NextMessage(true, "OK");
                }
                else
                {
                    Program.queue.NextMessage(false, "error");
                }
            }
            SleepThread(1);

            Program.sc.SendResults();
        }

        public void SleepThread(int seconds)
        {
            for (var i = 0; i < seconds * 2; i++)
            {
                Application.DoEvents();
                Thread.Sleep(500);
            }
        }

        
    }
}
