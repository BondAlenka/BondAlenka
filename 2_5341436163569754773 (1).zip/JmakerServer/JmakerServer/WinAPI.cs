﻿// Decompiled with JetBrains decompiler
// Type: Jmaker.WinAPI
// Assembly: Jmaker, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F7663B89-0B2D-4474-A161-E78A8B1A5775
// Assembly location: D:\Dev\Messengers\ViberClicker\JmakerStart.exe

using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;

namespace JmakerServer
{
    public static class WinAPI {
        private static IntPtr result;
        private static bool flag;

        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr FindWindow(string className, string windowName);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool EnumChildWindows(IntPtr hwnd, WinAPI.WindowEnumProc func, string lParam);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool EnumChildWindows(IntPtr hwnd, WinAPI.WindowEnumProcPtr func, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr SendMessage(IntPtr hwnd, uint msg, int wParam, int lParam);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr SendMessage(IntPtr hwnd, uint msg, int wParam, string lParam);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr PostMessage(IntPtr hwnd, uint msg, int wParam, int lParam);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern int GetAsyncKeyState(int vKey);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern int GetDlgItemText(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        private static extern void mouse_event(uint dwFlags, int dx, int dy, uint cButtons, uint dwExtraInfo);

        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(out Point pt);

        [DllImport("user32")]
        public static extern int SetCursorPos(int x, int y);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool GetWindowRect(IntPtr hwnd, out Rectangle lpRect);

        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool SetActiveWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);

        [DllImport("user32.dll")]
        public static extern IntPtr GetClipboardData(uint uFormat);

        [DllImport("kernel32.dll")]
        private static extern UIntPtr GlobalSize(IntPtr hMem);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GlobalLock(IntPtr hMem);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool OpenClipboard(IntPtr hWndNewOwner);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool CloseClipboard();

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        public static extern IntPtr GetActiveWindow();

        [DllImport("user32")]
        private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

        [DllImport("user32")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern uint GetCurrentThreadId();

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr GetFocus();

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hwnd, int nCmdShow);

        [DllImport("gdi32.dll", CharSet = CharSet.Auto, SetLastError = true, ExactSpelling = true)]
        public static extern int BitBlt(IntPtr hDC, int x, int y, int nWidth, int nHeight, IntPtr hSrcDC, int xSrc, int ySrc, int dwRop);

        public static void Click(IntPtr hwnd) {
            WinAPI.SendMessage(hwnd, 513U, 0, 0);
            WinAPI.SendMessage(hwnd, 514U, 0, 0);
        }

        public static void ClickPost(IntPtr hwnd) {
            WinAPI.PostMessage(hwnd, 513U, 0, 0);
            WinAPI.PostMessage(hwnd, 514U, 0, 0);
        }

        public static void Close(IntPtr hwnd) {
            WinAPI.SendMessage(hwnd, 16U, 0, 0);
        }

        public static void SetText(IntPtr hwnd, string text) {
            WinAPI.SendMessage(hwnd, 12U, 0, text);
        }

        public static string GetWindowText(IntPtr hwnd) {
            StringBuilder lpString = new StringBuilder((int) ushort.MaxValue);
            GetWindowText(hwnd, lpString, (int) ushort.MaxValue);
            return lpString.ToString();
        }

        public static string GetWindowClass(IntPtr hwnd) {
            StringBuilder lpClassName = new StringBuilder((int) ushort.MaxValue);
            GetClassName(hwnd, lpClassName, (int) ushort.MaxValue);
            return lpClassName.ToString();
        }

        public static IntPtr GetHwnd(string processName) {
            try {
                return Process.GetProcessesByName(processName)[0].MainWindowHandle;
            }
            catch {
                return IntPtr.Zero;
            }
        }

        public static IntPtr FindWindowByClass(IntPtr parentWindow, string className) {
            WinAPI.EnumChildWindows(parentWindow, new WinAPI.WindowEnumProc(WinAPI.EnumWindowByClassHandler), className);
            IntPtr num = WinAPI.result;
            WinAPI.result = IntPtr.Zero;
            return num;
        }

        public static IntPtr FindWindowByTitle(IntPtr parentWindow, string windowText) {
            WinAPI.EnumChildWindows(parentWindow, EnumWindowsByTitleHandler, windowText);
            IntPtr num = WinAPI.result;
            WinAPI.result = IntPtr.Zero;
            return num;
        }

        public static IntPtr FindWindowByPrevElement(IntPtr parentWindow, IntPtr prevElement) {
            WinAPI.EnumChildWindows(parentWindow, EnumWindowByPrevElementHandler, prevElement);
            IntPtr num = WinAPI.result;
            WinAPI.flag = false;
            WinAPI.result = IntPtr.Zero;
            return num;
        }

        public static IntPtr FinWindowByNextElement(IntPtr parentWindow, IntPtr nextElement) {
            EnumChildWindows(parentWindow, EnumWindowByNextElementHandler, nextElement);
            IntPtr num = result;
            flag = false;
            result = IntPtr.Zero;
            return num;
        }

        public static int EnumWindowsByTitleHandler(IntPtr hwnd, string lparam) {
            if (hwnd == IntPtr.Zero)
                return 0;
            string windowText = WinAPI.GetWindowText(hwnd);
            if (lparam != windowText)
                return 1;
            result = hwnd;
            return 0;
        }

        public static int EnumWindowByClassHandler(IntPtr hwnd, string lparam) {
            if (hwnd == IntPtr.Zero)
                return 0;
            string windowClass = GetWindowClass(hwnd);
            if (lparam != windowClass)
                return 1;
            result = hwnd;

            return 0;
        }

        public static int EnumWindowByPrevElementHandler(IntPtr hwnd, IntPtr lparam) {
            if (hwnd == IntPtr.Zero)
            return 0;
            if (flag) {
                result = hwnd;
                return 0;
            }
            if (!(hwnd == lparam))
                return 1;
            flag = true;
            return 1;
        }

        public static int EnumWindowByNextElementHandler(IntPtr hwnd, IntPtr lparam) {
            if (hwnd == IntPtr.Zero || hwnd == lparam)
                return 0;
            result = hwnd;
            return 1;
        }

        public static void RestoreWindow(IntPtr hwnd) {
            ShowWindow(hwnd, 9);
        }

        public static void SetCombobox(IntPtr hwnd, int index)  {
            SendMessage(hwnd, 334U, index, 0);
        }

        public static void MouseMove(int posX, int posY) {
            mouse_event(1U, posX, posY, 0U, 0U);
        }

        public static void MouseClick(int posX, int posY) {
            mouse_event(6U, posX, posY, 0U, 0U);
        }

        public static Rectangle GetWindowPosition(IntPtr hwnd) {
            Rectangle lpRect;
            GetWindowRect(hwnd, out lpRect);
            return lpRect;
        }

        public static string GetClipboardData() {
            OpenClipboard(IntPtr.Zero);
            IntPtr clipboardData = GetClipboardData(1U);
            UIntPtr num = GlobalSize(clipboardData);
            IntPtr source = GlobalLock(clipboardData);
            byte[] numArray = new byte[(int) (uint) num];
            Marshal.Copy(source, numArray, 0, (int) (uint) num);
            CloseClipboard();
            return new UTF8Encoding().GetString(numArray);
        }

        public static void PressKey(KeyCode keyCode) {
            keybd_event((byte) keyCode, (byte) 0, 0U, 0);
            keybd_event((byte) keyCode, (byte) 0, 2U, 0);
        }

        public static IntPtr GetFocusedControl() {
            IntPtr foregroundWindow = GetForegroundWindow();
            uint lpdwProcessId = 0U;
            AttachThreadInput(GetWindowThreadProcessId(foregroundWindow, out lpdwProcessId), GetCurrentThreadId(), true);
            IntPtr focus = GetFocus();
            AttachThreadInput(GetWindowThreadProcessId(foregroundWindow, out lpdwProcessId), GetCurrentThreadId(), false);
            return focus;
        }


        public delegate int WindowEnumProc(IntPtr hwnd, string lparam);

        public delegate int WindowEnumProcPtr(IntPtr hwnd, IntPtr lparam);
    }
}
