﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace JmakerServer
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        
        public static Queue queue = new Queue();
        public static ServiceConnector sc = new ServiceConnector();
        public static AccountController ac = new AccountController();
        public static QueueProcessor qp = new QueueProcessor();
        public static string InstanceName = "";
        
        [STAThread]
        static void Main()
        {
            InstanceName = "Untitled";

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
