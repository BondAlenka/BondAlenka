﻿using System;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace JmakerServer
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtServiceUrl.Text = Program.sc.Url;
            txtInstanceName.Text = Program.InstanceName;
        }

        private void btnSetSettings_Click(object sender, EventArgs e)
        {
            Program.sc.Url = txtServiceUrl.Text;
            Program.InstanceName = txtInstanceName.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tmProcess.Enabled = true;
        }

        private void tmProcess_Tick(object sender, EventArgs e)
        {
            tmProcess.Enabled = false;
            Program.qp.ProcessBatch();
            tmProcess.Enabled = true;
        }

        private void btnRun1_Click(object sender, EventArgs e)
        {
            Program.ac.CloseViber();
            
            var si = new ProcessStartInfo();

            var AccUser = "7903.......";
            var AccDrive = "C:";
            //var AccRoot = "\\Users\\" + AccUser;
            var AccRoot = "\\ViberAccounts\\Accounts\\" + AccUser;

            si.EnvironmentVariables["USERNAME"] = AccUser;
            si.EnvironmentVariables["APPDATA"] = AccDrive + AccRoot + "\\AppData\\Roaming";
            si.EnvironmentVariables["HOMEPATH"] = AccRoot;
            si.EnvironmentVariables["LOCALAPPDATA"] = AccDrive + AccRoot + "\\AppData\\Local";
            si.EnvironmentVariables["USERPROFILE"] = AccDrive + AccRoot;
            si.FileName = "C:\\ViberAccounts\\_\\Viber\\viber.exe";
            si.UseShellExecute = false;

            var p = new Process() {StartInfo = si};
            p.Start();
        }

        private void btnRun2_Click (object sender, EventArgs e)
        {
            Program.ac.CloseViber();

            var si = new ProcessStartInfo();

            var AccUser = "380.........";
            var AccDrive = "C:";
            var AccRoot = "\\ViberAccounts\\Accounts\\" + AccUser;

            si.EnvironmentVariables["USERNAME"] = AccUser;
            si.EnvironmentVariables["APPDATA"] = AccDrive + AccRoot + "\\AppData\\Roaming";
            si.EnvironmentVariables["HOMEPATH"] = AccRoot;
            si.EnvironmentVariables["LOCALAPPDATA"] = AccDrive + AccRoot + "\\AppData\\Local";
            si.EnvironmentVariables["USERPROFILE"] = AccDrive + AccRoot;
            si.FileName = "C:\\ViberAccounts\\_\\Viber\\viber.exe";
            si.UseShellExecute = false;

            var p = new Process() { StartInfo = si };
            p.Start();
        }

       
    }
}
