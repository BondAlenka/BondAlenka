﻿using System;
using System.Drawing;

namespace JmakerServer
{
    internal class PositionsManager {
        private PositionsOfControls positions = new PositionsOfControls();
        private IntPtr mainWindow;

        public PositionsManager(IntPtr mainWindow) {
            this.mainWindow = mainWindow;
        }

        public Point GetPointByName(string name) {
            try {
                Rectangle windowPosition = WinAPI.GetWindowPosition(mainWindow);
                Point point = positions[name];
                return new Point(point.X + windowPosition.X, point.Y + windowPosition.Y);
            }
            catch {
                return new Point();
            }
        }
    }
}
