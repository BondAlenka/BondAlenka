﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace JmakerServer
{
    class Logger
    {
        private static string _path = "";

        public static void Write(string line, string filename = "jmaker.log")
        {
            if (_path == "")
                _path = Path.Combine(Application.StartupPath, filename);

            var writer = new StreamWriter(_path, true, Encoding.UTF8);
            writer.WriteLine(DateTime.Now.ToShortDateString() + " " + 
                DateTime.Now.ToShortTimeString() + "> " + line);

            writer.Close();

            Program.sc.SendLogMessage(line);
        }
    }
}
